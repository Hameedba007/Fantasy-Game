public class NoteBook
{
private NoteBookGUI view;
private NoteBookData data;
//Konstruktor
public NoteBook()
{
data = new NoteBookData();
view = new NoteBookGUI(data);
}
public static void main(String[] args)
{
NoteBook notebook = new NoteBook();
//NoteBook data = new NoteBook();
//Sichtbarkeit des Notebooks
notebook.view.setVisible(true);
}
}