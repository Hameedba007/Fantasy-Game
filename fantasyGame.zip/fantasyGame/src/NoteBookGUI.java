import java.awt.Color;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextArea;



public class NoteBookGUI extends JFrame  {//
	private static final long serialVersionUID = 1L;
	//Verknuepfung mit der Daten-Klasse
	private NoteBookData daten;
	
	//Komponenten
	private JLabel wochentagLabel;
	private JComboBox<String>wochentag;
	private String[] tage={"Montag","Dienstag","Mittwoch",
	"Donnerstag","Freitag","Samstag","Sonntag"};
	
	//Attribute fuer alle Komponenten der GUI
	private JLabel termineLabel;
	private JTextArea termine;
	
	private JButton showButton;
	private JButton saveButton;
	private JButton clearButton;
	private JButton exitButton;
	

	
	//kostruktur
	public NoteBookGUI (NoteBookData d)
	{	//ausserdem:
		//Titel+Groesse+Location fuer das Fenster
		//alle Komponenten erzeugen+konfigurieren+hinzufuegen
		
	this.daten = d;
	//JFrame konfigurieren
	this.setTitle("دفترچه یادداشت");
	this.setSize(400, 300);
	this.setLocation(500, 300);
	
	//JPanel-counter & Layout festlegen
	this.setLayout(null);
	//Farbe der ContentPane aendern
	this.getContentPane().setBackground(Color.LIGHT_GRAY);

	//Komponenten des JPanels
	wochentagLabel= new JLabel ("Wochentag");
	//Konfiguration der Komponente
	wochentagLabel.setBounds(20,5,110,30);
	this.add(wochentagLabel);
	
	wochentag= new JComboBox<String>(tage);
	//Konfiguration der Komponente
	wochentag.setBounds(20,30,110,30);
	//Platzieren auf der ContentPane
	this.add(wochentag);
	
	termineLabel= new JLabel ("Termine");
	termineLabel.setBounds(160,5,110,30);
	this.add(termineLabel);
	
	termine= new JTextArea ();
	termine.setBounds(160,30,200,200);
	this.add(termine);
	
	showButton= new JButton ("Anzeigen");
	showButton.setBounds(20,120,110,20);
	this.add(showButton);
	
	saveButton= new JButton ("Speichern");
	saveButton.setBounds(20,150,110,20);
	this.add(saveButton);
	
	clearButton= new JButton ("Loeschen");
	clearButton.setBounds(20,180,110,20);
	this.add(clearButton);
	
	exitButton= new JButton ("Beenden");
	exitButton.setBounds(20,210,110,20);
	this.add(exitButton);
	
	//Lambda-Listener

	showButton.addActionListener(e-> anzeigen());
	saveButton.addActionListener(e-> speichern());
	clearButton.addActionListener(e-> {termine.setText(null);});
	exitButton.addActionListener(e-> {System.exit(0);});
}
	
	private void speichern()
	{
		daten.speichernTermin(wochentag.getSelectedItem().toString(), termine.getText());
	}
	public void anzeigen()
	{
	
		String w= wochentag.getSelectedItem().toString();
		String t = daten.holenTermin(w);
		if(t!=null)//if(daten.holenTermin(wochentag.getSelectedItem().toString()) != null)
			termine.setText(t); //termine – Attribut fuer JTextArea
		else
			termine.setText("Keine Termine!");
	
	}
}
	


