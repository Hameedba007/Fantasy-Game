import java.util.HashMap;

public class NoteBookData {
	private HashMap<String,String> daten;
	
	//Konstruktur
	public NoteBookData() {
		daten = new HashMap<String,String>();
	}
	//speichern
	public void speichernTermin(String wtag, String termine) {
		daten.put(wtag,termine);
		System.out.println("Termin [" + wtag +" : " + termine+" ] gespeichert!");
	}
	//Lesen der Termine zu einem Wochentag
	
	
	
	public String holenTermin(String wtag) {
		return daten.get(wtag);}
	
}
